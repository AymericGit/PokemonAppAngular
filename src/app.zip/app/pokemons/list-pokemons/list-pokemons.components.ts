import { Component } from '@angular/core';
import { OnInit } from '@angular/core';

import { Pokemon } from '../donnees-pokemons/pokemons';
import { POKEMONS } from '../donnees-pokemons/mock-pokemons';

@Component({
    selector: "list-pokemons",
    templateUrl: "./list-pokemons.components.html"
})
export class PokemonComponent implements OnInit {
  
    pokemons: Pokemon[];

    constructor() {
        this.pokemons = [];
    }

    ngOnInit() {
        this.pokemons = POKEMONS;
    }
}