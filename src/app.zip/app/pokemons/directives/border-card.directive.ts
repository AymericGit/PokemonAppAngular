import { Directive, Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[pkmnBorderCard]'
})
export class BorderCardDirective {
    private initialColor: string = "#f5f5f5"
    private defaultColor: string = "#009688"
    private defaultHeight: number = 200;
    private borderColor: string = "#009688"

    constructor(private el: ElementRef) {

    }

    @HostListener('mouseenter') onMouseEnter() {
        this.setBorder(this.borderColor || this.defaultColor);
    }

    private setBorder(color: string) {
        let border = 'solid 4px' + color;
        this.el.nativeElement.style.border = border;
    }

}
