import { Component } from '@angular/core';

@Component({
    selector: 'page-404',
    templateUrl: './page-not-found.component.html'
})
export class PageNotFoundComponent {

}